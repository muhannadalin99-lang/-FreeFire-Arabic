plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.fftraining"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.fftraining"
        minSdk = 23
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
}
