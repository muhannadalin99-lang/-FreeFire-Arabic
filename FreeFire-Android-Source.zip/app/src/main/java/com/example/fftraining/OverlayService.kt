package com.example.fftraining

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xEE142235.toInt())
        }
        val title = TextView(this).apply {
            text = "قائمة التدريب  •  اسحب من العنوان لتحريكها"
            textSize = 14f
            setTextColor(0xFF8DF5C1.toInt())
            setPadding(4, 6, 4, 10)
        }
        box.addView(title)
        box.addView(info("مؤشر التصويب: أداة مرئية للتدريب"))
        box.addView(info("تتبع الهدف: تدريب بصري فقط"))
        box.addView(info("مسار الطلقة: عرض توضيحي فقط"))
        box.addView(Button(this).apply {
            text = "إخفاء القائمة"
            setOnClickListener { stopSelf() }
        })

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 120
        }

        // Drag the panel by touching its title.
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        title.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(box, params)
                    true
                }
                else -> false
            }
        }

        panel = box
        windowManager.addView(box, params)
        return START_NOT_STICKY
    }

    private fun info(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(0xFFFFFFFF.toInt())
        setPadding(4, 6, 4, 6)
    }

    override fun onDestroy() {
        panel?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        panel = null
        super.onDestroy()
    }
}
