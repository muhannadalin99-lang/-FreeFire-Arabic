package com.example.fftraining

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val normal = "com.dts.freefireth"
    private val max = "com.dts.freefiremax"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF101B29.toInt())
        }
        fun label(text: String, size: Float, color: Int): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                setPadding(8, 14, 8, 14)
            }
        fun button(text: String, action: () -> Unit) =
            Button(this).apply {
                this.text = text
                textSize = 16f
                setOnClickListener { action() }
            }

        layout.addView(label("مساعد التدريب", 27f, 0xFF8DF5C1.toInt()))
        layout.addView(label("اختر نسخة اللعبة", 17f, 0xFFFFFFFF.toInt()))
        layout.addView(button("فتح Free Fire العادية") { launchGame(normal) })
        layout.addView(button("فتح Free Fire MAX") { launchGame(max) })
        layout.addView(button("إظهار قائمة التدريب العائمة") { showOverlay() })
        layout.addView(button("إيقاف القائمة العائمة") {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "تم إيقاف القائمة", Toast.LENGTH_SHORT).show()
        })
        layout.addView(label(
            "الأدوات للتدريب البصري فقط، ولا تعدّل اللعبة أو تمنح إصابة تلقائية.",
            13f, 0xFFB6C4D4.toInt()
        ))
        setContentView(layout)
    }

    private fun launchGame(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch == null) {
            Toast.makeText(this, "هذه النسخة غير مثبتة على جهازك", Toast.LENGTH_LONG).show()
        } else {
            startActivity(launch)
        }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "فعّل الظهور فوق التطبيقات ثم ارجع واضغط الزر", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "ظهرت قائمة التدريب", Toast.LENGTH_SHORT).show()
    }
}
